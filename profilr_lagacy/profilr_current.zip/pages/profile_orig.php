<!DOCTYPE html>
<html>
<?php include("../views/profile_head.html"); ?>
<body class="Site">
<div class="ui grid container Site-content" style="width: 90% !important;padding-top: 30px;">
	<?php include("../views/profile_nav.html"); ?>

    <!-- content row -->
    <div class="row">
        <div class="ui two column grid">
            <div class="ui twelve wide column">
                <spcontent>

                </spcontent>
            </div>
            <div class="ui three wide column">
                <side>
					<?php include("../views/profile_side.html"); ?>
                </side>

            </div>

        </div>

    </div>


</div>

<footer></footer>


<?php include("../views/scripts.html"); ?>


</body>
</html>