<!-- profile summary-->
<div class="ui segment" style="margin-bottom: 40px;">
    <div class="ui bottom attached label"><i class="ui write icon"></i>Edit</div>
    <div class="ui items">
        <div class="item">
            <a class="ui small image"><img src="images/image.png"></a>
            <div class="content">
                <a class="header">ISHOLA ISSAC</a>
                <div class="description" style="height:100px;overflow-y: auto">
                    <p>Cute dogs come in a variety of shapes and sizes. Some cute dogs are cute for their adorable
                        faces, others for their tiny stature, and even others for their massive size.</p>
                    <p>Many people also have their own barometers for what makes a cute dog.</p>
                </div>
            </div>
        </div>
    </div>
</div>


<!--profile summary -->


<div class="ui segment" style="margin-bottom: 40px; height: 30vh;overflow-y: auto">
    <div class="ui top attached blue label">Educational Qualifications</div>
    <div class="ui bottom attached label"><i class="ui write icon"></i>Edit | Attach Media:</div>
</div>


<div class="ui segment" style="margin-bottom: 40px; height: 30vh;overflow-y: auto"">
<div class="ui top attached blue label">Professional Certifications/Courses</div>
<!-- <a class="ui blue left ribbon label">Professional Certifications/Courses</a> -->
<div class="ui bottom attached label"><i class="ui write icon"></i>Edit | Attach Media:</div>

</div>


<div class="ui segment" style="margin-bottom: 40px; height: 30vh;overflow-y: auto"">
<div class="ui top attached blue label">Industry Experience</div>
<!-- <a class="ui blue left ribbon label">Professional Certifications/Courses</a> -->
<div class="ui bottom attached label"><i class="ui write icon"></i>Edit | Attach Media:</div>

</div>


<div class="ui segment" style="margin-bottom: 40px; height: 30vh;overflow-y: auto"">
<div class="ui top attached blue label">Specific Specializations</div>
<!-- <a class="ui blue left ribbon label">Professional Certifications/Courses</a> -->
<div class="ui bottom attached label"><i class="ui write icon"></i>Edit | Attach Media:</div>

</div>


<div class="ui segment" style="margin-bottom: 40px; height: 30vh;overflow-y: auto"">
<div class="ui top attached blue label">Past Jobs Done</div>
<!-- <a class="ui blue left ribbon label">Professional Certifications/Courses</a> -->
<div class="ui bottom attached label"><i class="ui write icon"></i>Edit | Attach Media:</div>

</div>


<div class="ui segment" style="margin-bottom: 40px; height: 30vh;overflow-y: auto"">
<div class="ui top attached blue label">Testimonials</div>
<!-- <a class="ui blue left ribbon label">Professional Certifications/Courses</a> -->
<div class="ui bottom attached label"><i class="ui write icon"></i>Edit | Attach Media:</div>

</div>

<div class="ui segment" style="margin-bottom: 40px; height: 30vh;overflow-y: auto"">
<div class="ui top attached blue label">References</div>
<!-- <a class="ui blue left ribbon label">Professional Certifications/Courses</a> -->
<div class="ui bottom attached label"><i class="ui write icon"></i>Edit | Attach Media:</div>

</div>


<script type="text/javascript">
    $('.ui.dropdown')
        .dropdown()
    ;
    //myApp.onReady();
</script>

