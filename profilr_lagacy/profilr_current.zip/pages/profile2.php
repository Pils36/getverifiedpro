<!-- profile summary-->
<div class="ui grid">
    <div class="row">

        <div class="ui  attached segment">
            <div class="ui items">
                <div class="item">
                    <a class="ui small image">
                        <img src="images/image.png">
                    </a>
                    <div class="content">
                        <a class="header">
                            <div id="profile_name">Adesoye Olaloye</div>
                        </a>
                        <div class="description" id="profile_summary">
                            <h4 class="ui header">Systems Engineer</h4>

                            <p>Cute dogs come in a variety of shapes and sizes. Some cute dogs are cute for their
                                adorable faces, others for their tiny stature, and even others for their massive
                                size.</p>
                            <p>Many people also have their own barometers for what makes a cute dog.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="ui compact bottom attached menu">
            <a class="item">
                <i class="camera retro icon"></i>
                <div id="profile_photo"></div>
            </a>
            <a class="item">
                <i class="write icon"></i>
                Edit Profile
            </a>

        </div>
    </div>
</div>
<!-- educational qualifications-->
<div class="ui grid">
    <div class="row">

    </div>
</div>
<!-- professional certifications -->
<div class="row">

</div>


<!-- Industry Experience-->
<div class="row"></div>

<!-- specific specializations -->
<div class="row"></div>

<!-- past jobs -->
<div class="row"></div>


<!-- testimonials -->
<div class="row"></div>


<!-- references -->
<div class="row"></div>




