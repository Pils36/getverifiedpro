<?php include("../views/head.html"); ?>
<body class="Site">
<div class="ui grid container Site-content" style="width: 90% !important;padding-top: 30px;">
	<?php include("../views/home_nav.html"); ?>
    <!-- content row -->

    <div class="row" id="content_row">
        <div class="twelve wide column">
            <div class="ui  vertical segment">
				<?php include("../views/right_rail.html"); ?>
                <spcontent>
                    <h3 class="ui header">Commonly Asked Questions</h3>
                    <div class="ui vertical segment" style="height: 65vh;overflow-y: auto">

                    </div>

                </spcontent>

            </div>
        </div>
    </div>
    <!-- content row ends-->

</div>
<footer>
	<?php include("../views/footer.html"); ?>
</footer>
<?php include("../views/scripts.html"); ?>
</body>
