<?php include("../views/head.html"); ?>
<body class="Site">
<div class="ui grid container Site-content" style="width: 90% !important;padding-top: 30px;">
	<?php include("../views/home_nav.html"); ?>
    <!-- content row -->

    <div class="row" id="content_row">
        <div class="ui two wide column"></div>
        <div class="ui twelve wide column">
            <div class="ui  vertical segment">

                <spcontent>
                    <h3 class="ui header">Help & Feedback</h3>
                    <div class="ui vertical segment" style="height: 60vh;overflow-y: auto">

                    </div>
                </spcontent>

            </div>
        </div>
        <div class="ui two wide column"></div>
    </div>
    <!-- content row ends-->

</div>
<footer>
	<?php include("../views/footer.html"); ?>
</footer>
<?php include("../views/scripts.html"); ?>
</body>

