<?php include("../views/head.html"); ?>
<body class="Site">
<div class="ui grid container Site-content" style="width: 90% !important;padding-top: 30px;">

    <!-- content row -->
	
	<?php include("../views/home_nav.html"); ?>

    <div class="ui row grid">
        <div class="row">
            <div class="ui four wide column"></div>


            <div class="ui eight wide column" id="verify_response"></div>


            <div class="ui four wide column"></div>


        </div>
    </div>

</div>

<footer>
	<?php include("../views/footer.html"); ?>
</footer>

<?php include("../views/scripts.html"); ?>
<script type="text/javascript" src="../js/app.js"></script>
<script type="text/javascript" src="../js/verify.js"></script>

</body>
</html>