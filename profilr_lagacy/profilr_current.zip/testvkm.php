<?php
$myArray = array();
echo json_encode($myArray);
?>