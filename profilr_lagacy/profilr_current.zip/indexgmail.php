<?php
session_start();

echo $_SESSION['access_token'];

?>