<?php

define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'profilr_user');
define('DB_PASSWORD', 'portFOLIO_2015');
define('DB_NAME', 'profilr_beta');
define('DB_PORT', 3306);
define('APP_DOMAIN', 'https://beta.pro-filr.com/');
define('ROOT',  '/home/profilr/public_html/profilr_beta/');

//define('DB_HOSTNAME', 'localhost');
//define('DB_USERNAME', 'root');
//define('DB_PASSWORD', '');
//define('DB_NAME', 'profilr');
//define('DB_PORT', 3306);
//define('APP_DOMAIN', 'http://localhost/profilr/profilr_app/public_html/');
//define('ROOT', $_SERVER['DOCUMENT_ROOT'] . '/profilr/profilr_app/');

define('DOCUMENT_ROOT', ROOT . '/public_html/');
define('COMPOSER_AUTOLOAD', TRUE);
define('VIEWS', DOCUMENT_ROOT . 'views/');

define('LINKEDIN_CLIENT_ID', '77g9qzxthk6iob');
define('LINKEDIN_CLIENT_SECRET', 'XucYpXzrUB0dBqfm');
define('LINKEDIN_REDIRECT_URL', APP_DOMAIN . 'controller/app.php');

define('GOOGLE_CLIENT_ID', '89097082331-ndueuj81dat4goc09dqqo3oonvg1eg59.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', 'fn9BO3X8zGTRSxy0LE_l0aio');
define('GOOGLE_REDIRECT_URL',  APP_DOMAIN . 'controller/app.php');


define('SECRET_KEY', 'Jimoh2016');
define('ALGORITHM', 'HS512');

ini_set('max_execution_time', 0);

