<?php
/**
 * Created by PhpStorm.
 * User: Funsho Olaniyi
 * Date: 12/04/2018
 * Time: 03:50 AM
 */

class Reports
{
	private $dbh;
	
	public function __construct()
	{
		$this->dbh = Database::getInstance();
	}
	
	public function getNumOfNewSignUps(){
		$total = (int) $this->getTotalNumOfUsers();
		$completed = (int) $this->getNumOfCompletedProfiles();
		
		return (int) ($total - $completed);
	}
	
	public function getNumOfCompletedProfiles(){
		$sql = "SELECT tbl_account_individual.id FROM tbl_account_individual JOIN tbl_industry_experience ON tbl_industry_experience.login_id = tbl_account_individual.login_id JOIN tbl_educational_qualification ON tbl_educational_qualification.login_id = tbl_account_individual.login_id JOIN tbl_affiliation ON tbl_affiliation.login_id = tbl_account_individual.login_id GROUP BY tbl_account_individual.login_id";
		$stmt = $this->dbh->prepare($sql);
		$stmt->execute();
		return $count = $stmt->rowCount();
	}
	
	public function getTotalNumOfUsers(){
		$sql = "SELECT id FROM tbl_account_individual";
		$stmt = $this->dbh->prepare($sql);
		$stmt->execute();
		return $count = $stmt->rowCount();
	}
	
	public function getNumOfClassicUsers(){
		$sql = "SELECT tbl_account_individual.id FROM tbl_account_individual JOIN tbl_subscription ON tbl_account_individual.login_id = tbl_subscription.login_id WHERE plan != 1 GROUP BY tbl_account_individual.login_id";
		$stmt = $this->dbh->prepare($sql);
		$stmt->execute();
		return $count = $stmt->rowCount();
	}
	
	public function getNumOfValidations(){
		$sql = "SELECT id FROM tbl_validation";
		$stmt = $this->dbh->prepare($sql);
		$stmt->execute();
		return $count = $stmt->rowCount();
	}
	
	public function getNumOfProfileViewed(){
		$sql = "SELECT id FROM tbl_profile_views";
		$stmt = $this->dbh->prepare($sql);
		$stmt->execute();
		return $count = $stmt->rowCount();
	}
	
	public function getNumOfPostedOpportunities(){
		$sql = "SELECT id FROM tbl_opportunity";
		$stmt = $this->dbh->prepare($sql);
		$stmt->execute();
		return $count = $stmt->rowCount();
	}
	
	public function getNumOfActiveOpportunities(){
		$sql = "SELECT id FROM tbl_opportunity WHERE tbl_opportunity.status = 'open'";
		$stmt = $this->dbh->prepare($sql);
		$stmt->execute();
		return $count = $stmt->rowCount();
	}
	
	public function getNumOfExpiredOpportunities(){
		$sql = "SELECT id FROM tbl_opportunity WHERE tbl_opportunity.status = 'closed'";
		$stmt = $this->dbh->prepare($sql);
		$stmt->execute();
		return $count = $stmt->rowCount();
	}
}