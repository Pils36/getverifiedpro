<?php

class ProfileView
{
	
	private $dbh;
	
	public function __construct()
	{
		$this->dbh = Database::getInstance();
	}
	
	public function createUserProfileViews($viewed_by, $member_id)
	{
		try {
			$stmt = $this->dbh->prepare("INSERT INTO tbl_profile_views(viewed_by_login_id, member_login_id) VALUES (:viewed_by, :member_by)");
			$stmt->execute(array(
				":viewed_by" => $viewed_by,
				":member_by" => $member_id,
			));
			return $insertId = $this->dbh->lastInsertId();
		} catch (PDOException $ex) {
			return $ex->getMessage();
		}
	}
	
	
	public function getUserProfileViews($user_id)
	{
		$sql = "SELECT tbl_account_individual.* FROM tbl_profile_views JOIN tbl_account_individual ON tbl_account_individual.login_id = tbl_profile_views.viewed_by_login_id WHERE tbl_profile_views.member_login_id = {$user_id}";
		try {
			$company = $this->dbh->query($sql)->fetchAll(PDO::FETCH_ASSOC);
			return $company;
		} catch (Exception $ex) {
			return $ex->getMessage();
		}
	}
}