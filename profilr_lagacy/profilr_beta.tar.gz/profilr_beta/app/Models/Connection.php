<?php
/**
 * Created by PhpStorm.
 * User: Funsho Olaniyi
 * Date: 31/03/2018
 * Time: 03:18 PM
 */

class Connection
{
	
	private $dbh;
	
	public function __construct()
	{
		$this->dbh = Database::getInstance();
	}
	
	public function getConnectionSuggestions($login_id)
	{
		// same affiliation  4
		// executed projects 2
		// professional certificates 5
		// industry experience 3
		// educational qualification 6
		// company 1
		// WHERE THEY HAVE NOT VALIDATED nor MESSAGED EACH OTHER
		
		
		$sql1 = "SELECT tbl_account_individual.*, the_company.name AS in_common FROM tbl_company AS the_company JOIN tbl_company AS my_company ON my_company.name = the_company.name JOIN tbl_account_individual ON tbl_account_individual.login_id = the_company.login_id WHERE my_company.login_id = {$login_id} AND tbl_account_individual.login_id != {$login_id}";
		
		$sql2 = "SELECT tbl_account_individual.*, the_project.project_employer AS in_common FROM tbl_executed_project AS the_project JOIN tbl_executed_project AS my_project ON my_project.project_employer = the_project.project_employer JOIN tbl_account_individual ON tbl_account_individual.login_id = the_project.login_id WHERE my_project.login_id = {$login_id} AND tbl_account_individual.login_id != {$login_id}";
		
		$sql3 = "SELECT tbl_account_individual.*, the_experience.company AS in_common FROM tbl_industry_experience AS the_experience JOIN tbl_industry_experience AS my_experience ON my_experience.company = the_experience.company JOIN tbl_account_individual ON tbl_account_individual.login_id = the_experience.login_id WHERE my_experience.login_id = {$login_id} AND tbl_account_individual.login_id != {$login_id}";
		
		$sql4 = "SELECT tbl_account_individual.*, the_affiliation.organisation AS in_common FROM tbl_affiliation AS the_affiliation JOIN tbl_affiliation AS my_affiliation ON my_affiliation.organisation = the_affiliation.organisation JOIN tbl_account_individual ON tbl_account_individual.login_id = the_affiliation.login_id WHERE my_affiliation.login_id = {$login_id} AND tbl_account_individual.login_id != {$login_id}";
		
		$sql5 = "SELECT tbl_account_individual.*, the_professional_certification.certification AS in_common FROM tbl_professional_certification AS the_professional_certification JOIN tbl_professional_certification AS my_professional_certification ON my_professional_certification.certification = the_professional_certification.certification JOIN tbl_account_individual ON tbl_account_individual.login_id = the_professional_certification.login_id WHERE my_professional_certification.login_id = {$login_id} AND tbl_account_individual.login_id != {$login_id}";
		
		$sql6 = "SELECT tbl_account_individual.*, the_educational_qualification.school AS in_common FROM tbl_educational_qualification AS the_educational_qualification JOIN tbl_educational_qualification AS my_educational_qualification ON my_educational_qualification.school = the_educational_qualification.school JOIN tbl_account_individual ON tbl_account_individual.login_id = the_educational_qualification.login_id WHERE my_educational_qualification.login_id = {$login_id} AND tbl_account_individual.login_id != {$login_id}";
		
		try {
			$result1 = $this->dbh->query($sql1)->fetchAll(PDO::FETCH_ASSOC);
			$result2 = $this->dbh->query($sql2)->fetchAll(PDO::FETCH_ASSOC);
			$result3 = $this->dbh->query($sql3)->fetchAll(PDO::FETCH_ASSOC);
			$result4 = $this->dbh->query($sql4)->fetchAll(PDO::FETCH_ASSOC);
			$result5 = $this->dbh->query($sql5)->fetchAll(PDO::FETCH_ASSOC);
			$result6 = $this->dbh->query($sql6)->fetchAll(PDO::FETCH_ASSOC);
			
			if (empty($result1)) $result1 = array();
			if (empty($result2)) $result2 = array();
			if (empty($result3)) $result3 = array();
			if (empty($result4)) $result4 = array();
			if (empty($result5)) $result5 = array();
			if (empty($result6)) $result6 = array();
			
			$results = array_merge($result1, $result2, $result3, $result4, $result5, $result6);
			$remove = $this->getMyConnections($login_id);
			// todo find a better implementation, or a better way to determine this
			$connected_login_ids = [];
			if(!empty($remove)){
				foreach ($remove as $item){
					$connected_login_ids[] = $item['login_id'];
				}
			}
			$the_filtered = [];
			if(!empty($results)){
				foreach ($results as $result) {
					$l = $result['login_id'];
					if(!in_array($l, $connected_login_ids)){
						$the_filtered[] = $result;
					}
				}
			}
			$results = make_array_unique($the_filtered, 'login_id');
			return $results;
		} catch (Exception $ex) {
			return $ex->getMessage();
		}
		
	}
	
	public function getMyConnections($login_id)
	{
		// people invited that are registered and verified
		// people messaged
		// people validated
		
		$sql1 = "SELECT tbl_account_individual.* FROM tbl_account_individual JOIN tbl_invites ON tbl_invites.sent_to = tbl_account_individual.email WHERE tbl_invites.login_id = {$login_id} AND tbl_account_individual.login_id != {$login_id} GROUP BY tbl_account_individual.login_id";
		
		$sql2 = "SELECT tbl_account_individual.* FROM (SELECT tbl_message.sent_to user_id FROM tbl_message WHERE tbl_message.sent_by={$login_id} AND tbl_message.message_type = 'private' GROUP BY tbl_message.sent_to UNION DISTINCT (SELECT  tbl_message.sent_by user2_id FROM tbl_message  WHERE tbl_message.sent_to = {$login_id} AND tbl_message.message_type = 'private' GROUP by tbl_message.sent_by)) T1 INNER JOIN tbl_account_individual ON (tbl_account_individual.login_id = T1.user_id) WHERE tbl_account_individual.login_id != {$login_id} GROUP BY T1.user_id DESC";
		
		$sql3 = "SELECT tbl_account_individual.* FROM (SELECT tbl_validation.member_id user_id FROM tbl_validation WHERE tbl_validation.validated_by={$login_id} GROUP BY tbl_validation.member_id UNION DISTINCT (SELECT  tbl_validation.validated_by user2_id FROM tbl_validation  WHERE tbl_validation.member_id = {$login_id} GROUP by tbl_validation.validated_by)) T1 INNER JOIN tbl_account_individual ON (tbl_account_individual.login_id = T1.user_id) WHERE tbl_account_individual.login_id != {$login_id} GROUP BY T1.user_id DESC";
		try {
			$result1 = $this->dbh->query($sql1)->fetchAll(PDO::FETCH_ASSOC);
			$result2 = $this->dbh->query($sql2)->fetchAll(PDO::FETCH_ASSOC);
			$result3 = $this->dbh->query($sql3)->fetchAll(PDO::FETCH_ASSOC);
			
			if (empty($result1)) $result1 = array();
			if (empty($result2)) $result2 = array();
			if (empty($result3)) $result3 = array();
			
			$results = array_merge($result1, $result2, $result3);
			$results = make_array_unique($results, 'login_id');
			return $results;
		} catch (Exception $ex) {
			return $ex->getMessage();
		}
	}
}