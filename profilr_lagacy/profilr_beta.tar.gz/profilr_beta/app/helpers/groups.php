<?php
/**
 * Created by PhpStorm.
 * User: Funsho Olaniyi
 * Date: 23/03/2018
 * Time: 10:50 AM
 */

function createGroup()
{
	$g = new Group();
	$myResponse = new Response();
	$member = $_SESSION['login_id'];
	
	if (empty($_POST['title'])) {
		$myResponse->status = "failed";
		$myResponse->message = "Please enter a valid title";
		return json_encode($myResponse);
	}
	if (empty($_POST['members_login_id'])) {
		$myResponse->status = "failed";
		$myResponse->message = "Please select members";
		return json_encode($myResponse);
	}
	
	try {
		$insertId = $g->create($_POST['title'], $member);
		$g->createGroupMember($insertId, $member);
		
		$members_login = $_POST['members_login_id'];
		if (!empty($members_login)) {
			foreach ($members_login as $login_id) {
				if ($g->checkIfGroupMember($insertId, $login_id) !== true) {
					$g->createGroupMember($insertId, $login_id);
				}
			}
		}
		$myResponse->status = "success";
		$myResponse->message = "Group Created Successfully";
		$myResponse->data = ['group_id' => $insertId];
		return json_encode($myResponse);
	} catch (PDOException $ex) {
		$myResponse = new Response("error", array(), $ex->getMessage());
		return json_encode($myResponse);
	}
}

function getAllGroups()
{
	$g = new Group();
	$myResponse = new Response();
	try {
		$groups = $g->getAllGroups();
		
		$myResponse->status = "success";
		$myResponse->message = "Operation Successful";
		$myResponse->data = $groups;
		return json_encode($myResponse);
	} catch (Exception $ex) {
		$myResponse->status = "failed";
		$myResponse->message = $ex->getMessage();
		return json_encode($myResponse);
	}
}


function fetchGroups()
{
	$g = new Group();
	$myResponse = new Response();
	$member = $_SESSION['login_id'];
	
	try {
		$groups = $g->getUserGroups($member);
		
		$myResponse->status = "success";
		$myResponse->message = "Operation Successful";
		$myResponse->data = $groups;
		return json_encode($myResponse);
	} catch (Exception $ex) {
		$myResponse->status = "failed";
		$myResponse->message = $ex->getMessage();
		return json_encode($myResponse);
	}
}

function getGroupMembers()
{
	$g = new Group();
	$myResponse = new Response();
	
	if (empty($_POST['group_id'])) {
		$myResponse->status = "failed";
		$myResponse->message = "Please select a group";
		return json_encode($myResponse);
	}
	
	$myResponse = new Response();
	try {
		$groupMembers = $g->getGroupMembers($_POST['group_id']);
		
		$myResponse->status = "success";
		$myResponse->message = "Operation Successful";
		$myResponse->data = $groupMembers;
		return json_encode($myResponse);
	} catch (Exception $ex) {
		$myResponse->status = "failed";
		$myResponse->message = $ex->getMessage();
		return json_encode($myResponse);
	}
}

function getAllMyGroupMembers()
{
	$g = new Group();
	$myResponse = new Response();
	$member = $_SESSION['login_id'];
	
	try {
		$groupMembers = $g->getAllMyGroupMembers($member);
		$myResponse->status = "success";
		$myResponse->message = "Operation Successful";
		$myResponse->data = $groupMembers;
		return json_encode($myResponse);
	} catch (Exception $ex) {
		$myResponse->status = "failed";
		$myResponse->message = $ex->getMessage();
		return json_encode($myResponse);
	}
}

function groupUser()
{
	$g = new Group();
	$myResponse = new Response();
	
	if (empty($_POST['group_id'])) {
		$myResponse->status = "failed";
		$myResponse->message = "Please select group";
		return json_encode($myResponse);
	}
	try {
		
		if ($g->checkIfGroupMember($_POST['group_id'], $_POST['member_id']) !== true) {
			$g->createGroupMember($_POST['group_id'], $_POST['member_id']);
		}
		$myResponse->status = "success";
		$myResponse->message = "Group Member Added";
		return json_encode($myResponse);
	} catch (PDOException $ex) {
		$myResponse = new Response("error", array(), $ex->getMessage());
		return json_encode($myResponse);
	}
}

function updateGroupName()
{
	$g = new Group();
	$myResponse = new Response();
	
	if (empty($_POST['title'])) {
		$myResponse->status = "failed";
		$myResponse->message = "Please enter a valid title";
		return json_encode($myResponse);
	}
	try {
		$g->updateGroup($_POST['group_id'], $_POST['title']);
		$myResponse->status = "success";
		$myResponse->message = "Group Updated";
		return json_encode($myResponse);
	} catch (PDOException $ex) {
		$myResponse = new Response("error", array(), $ex->getMessage());
		return json_encode($myResponse);
	}
}

function removeGroupMember()
{
	$g = new Group();
	$myResponse = new Response();
	try {
		$groups = $g->deleteGroupMember($_POST['group_id'], $_POST['login_id']);
		$myResponse->status = "success";
		$myResponse->message = "Operation Successful";
		$myResponse->data = $groups;
		return json_encode($myResponse);
	} catch (Exception $ex) {
		$myResponse->status = "failed";
		$myResponse->message = $ex->getMessage();
		return json_encode($myResponse);
	}
}

function removeGroup()
{
	$g = new Group();
	$member = $_SESSION['login_id'];
	$myResponse = new Response();
	try {
		$groups = $g->deleteGroup($_POST['group_id'], $member);
		$g->deleteAllGroupMembers($_POST['group_id']);
		$myResponse->status = "success";
		$myResponse->message = "Operation Successful";
		$myResponse->data = $groups;
		return json_encode($myResponse);
	} catch (Exception $ex) {
		$myResponse->status = "failed";
		$myResponse->message = $ex->getMessage();
		return json_encode($myResponse);
	}
}
