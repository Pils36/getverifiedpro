<?php

header('Expires: Sun, 01 Jan 2014 00:00:00 GMT');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Cache-Control: post-check=0, pre-check=0', FALSE);
header('Pragma: no-cache');


if (!validateLogin()) {
	$_SESSION['oauth_error'] = 'Please Login';
	header('Location: account');
	exit;
}
?>
<!DOCTYPE html>
<html>
<?php include("partials/b_head.html"); ?>
<link rel="stylesheet" href="assets/lib/bootstrap-select/css/bootstrap-select.min.css">

<?php //echo "token:".$_SESSION['token']; ?>
<body>
<?php include("partials/b_profile_nav.html"); ?>

<div class="container sections-wrapper">
    <div class="row">
        <div class="secondary col-md-3 col-sm-12 col-xs-12">
            <aside class="info aside section">
                <div class="section-inner">
                    <div class="content quote">
                        <ul class="list-unstyled">
                            <li><a href="posts">Opportunities</a></li>
                            <li><a href="posts">Messages</a></li>
                            <li class="active">Professional Groups</li>
                        </ul>
                    </div><!--//content-->
                </div><!--//section-inner-->
            </aside><!--//aside-->

        </div><!--//secondary-->

        <div class="primary col-md-6 col-sm-12 col-xs-12">
            <div id="frame">
                <div id="sidepanel">

                    <div id="group_body">
                        <div id='profile'>
                            <div class='wrap'><p>Groups</p>
                                <a href="#" style="padding: 0 10px;" data-toggle="modal" class="pull-right"
                                   data-target="#createGroup"><i class="fa fa-plus"></i> Group</a>

                            </div>
                        </div>
                        <div id='search'><label for=''><i class='fa fa-search' aria-hidden='true'></i></label><input
                                    type='text' id='groupTableSearch' placeholder='Search Groups...'/></div>
                        <div id="contacts">
                            <ul id="group_table_list">

                            </ul>
                        </div>
                    </div>

                </div>

                <div class="content">
                    <div id="group-info">

                    </div>
                    <div class="messages">
                        <ul id="message-outlet">

                        </ul>
                    </div>

                    <div class="message-input">
                        <form class="wrap hidden" id="message_group_form" method="post" action="controller/app.php">
                            <div class="upload">
                                <div class="drop">
                                    <ul id="file_upload_list">

                                    </ul>
                                </div>
                            </div>
                            <input type="text" id="group_message_text" class="form-control"
                                   placeholder="Write your message..."/>
                            <input type="hidden" id="group_id">
                            <input type="hidden" id="attachedFiles">
                            <button class="submit" type="submit"><i class="fa fa-paper-plane" aria-hidden="true"></i>
                            </button>
                            <div class="clearfix"></div>
                            <div id="upload" class="upload">
                                <div id="drop" class="drop">
                                    <a><span>Attach File <i class="fa fa-paperclip attachment"
                                                            aria-hidden="true"></i></span></a>
                                    <input type="file" name="attachment" multiple/>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div><!--//masonry-->
        </div><!--//primary-->
        <div class="secondary col-md-3 col-sm-12 col-xs-12">
            <aside class="info aside section">
                <div class="section-inner" id="third-row-data-outlet">

                </div>
            </aside>
        </div>
    </div>

    <!-- Create Group Modal -->
    <div class="modal fade" id="createGroup" tabindex="-1" role="dialog" aria-labelledby="createGroupLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="createGroupLabel">Create Group</h4>
                </div>
                <div class="modal-body">
                    <div id="group_response"></div>
                    <form id="create_group_form" autocomplete="off">
                        <div class="form-group">
                            <label for="title">Group Name</label>
                            <input type="text" class="form-control" id="group_title" placeholder="Group Name">
                        </div>
                        <div class="form-group">
                            <label for="members">Select Members</label>
                            <select id="search_member" class="form-control selectpicker" multiple
                                    data-live-search="true">
                            </select>
                        </div>
                        <button type="submit" class="btn btn-default">Submit</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
	<?php include("partials/scripts.html"); ?>
    <script type="text/javascript" src="assets/lib/bootstrap-select/js/bootstrap-select.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('.selectpicker').selectpicker();
        });
    </script>
    <script type="text/javascript" src="assets/js/groups.js"></script>

    <script src="assets/upload/js/jquery.knob.js"></script>
    <script src="assets/upload/js/jquery.ui.widget.js"></script>
    <script src="assets/upload/js/jquery.iframe-transport.js"></script>
    <script src="assets/upload/js/jquery.fileupload.js"></script>
    <script src="assets/upload/js/script.js"></script>
</body>
</html>
