var group = group || {};
(function () {
    this.onReady = function () {
        group.getUserAccounts();
        group.loadGroups();
        $('#groups').on('click', function () {
            $("#group_body").removeClass('hidden');


            $(".message-input").addClass('hidden');
            $("#group-info").html('');
            $("#message-outlet").html('');
            $("#third-row-data-outlet").html('');

            group.loadGroups();

        });
    };

    this.loadGroups = function () {

        $("#groups").addClass('active');
        group.getGroupList();
    };

    this.getGroupList = function () {
        NProgress.start();
        var data = {
            "function": "fetchGroups"
        };
        sendRequest.postJSON(data, "controller/app.php", function (response) {
            if (response.status === "success") {
                group.groupListTemplate(response.data);
            }


        });
        NProgress.done();
    };

    this.groupListTemplate = function (data) {
        if (!data.length) {
            $("#group_table_list").html(group.emptyResponse);
            return;
        }
        var strPosts = '';
        $.each(data, function (k, v) {
            strPosts += "<li class='contact group-item rw' onclick='group.getGroupData(this)' id='" + v.id + "'><div class='wrap'><div class='meta'>" +
                "<p class='name'>" + v.title + "</p>" +
                "</div></div></li>";
        });
        strPosts += ' ';
        $("#group_table_list").html(strPosts);

    };


    this.emptyResponse = "<div class='ui comments'><div class='comment'><div class='text'>No record found</div> </div></div>";


    $('#create_group_form')
        .form({
            onSuccess: function (event, fields) {
                event.preventDefault();
                group.createGroup();
            }
        });


    this.createGroup = function () {
        var data = {
            "function": "createGroup",
            "title": $("#group_title").val(),
            "members_login_id": $("#search_member").val()
        };
        sendRequest.postJSON(data, "controller/app.php", function (response) {
            $("#group_response").html("<p style='text-align:center; color:red;'>" + response.message + "</p>");
            if (response.message === $.trim("Group Created Successfully")) {
                window.location.reload(true);
                group.getGroupList();
                $("#createGroup").modal("hide");
            }
        });

    };

    this.getGroupData = function (gift) {

        $("#message_group_form").removeClass('hidden');

        $('.group-item').removeClass('active');
        $(gift).addClass("active");
        var group_id = gift.id;
        group.fetchGroupMembers(group_id);
        group.fetchGroupMessages(group_id);
    };


    this.fetchGroupMessages = function (group_id) {
        NProgress.start();
        var data = {
            "function": "getGroupMessages",
            "group_id": group_id
        };
        sendRequest.postJSON(data, "controller/app.php", function (response) {
            if (response.status === "success") {
                group.groupMessagesTemplate(group_id, response.data);
            }


        });
        NProgress.done();
    };

    this.fetchGroupMembers = function (group_id) {

        var data = {
            "function": "getGroupMembers",
            "group_id": group_id
        };
        sendRequest.postJSON(data, "controller/app.php", function (response) {
            if (response.status === "success") {
                group.groupMembersTemplate(group_id, response.data);
            }


        });
    };


    this.groupMembersTemplate = function (group_id, data) {

        var deleteB = (myProfileData.login_id === data[0].owner_login_id) ? '<a href="#" class="pull-right" group_id="' + data[0].group_id + '" title="remove"  onclick="return confirm(\'Are you sure, you want to remove ' + data[0].title + '\') ? group.removeGroup(this): \'\' "><i class="fa fa-trash"></i></a>' : '';


        var strMembers = '<h1 class="heading">' + data[0].title + ' Members' + deleteB + '</h1><br>';
        strMembers += '<div class="content quote"></div><ul class="list-unstyled">';

        $.each(data, function (k, v) {
            var type = v.login_id === v.owner_login_id ? 'Admin' : 'Member';
            var deleteB = (myProfileData.login_id === v.owner_login_id || myProfileData.login_id === v.login_id) ? '<a href="#" group_id="' + v.group_id + '" login_id="' + v.login_id + '" title="remove"  onclick="return confirm(\'Are you sure, you want to remove ' + v.firstname + ' ' + v.lastname + '\') ? group.removeGroupMember(this): \'\' "><i class="fa fa-trash"></i></a>' : '';

            var onlineStatus = v.online_status ? "<i class='fa fa-dot-circle-o' style='color: green'></i>" : "<i class='fa fa-dot-circle-o'></i>";

            strMembers += '<li><a onclick="group.redirectProfile(this)"  data-account="' + v.login_id + '"><span><img src="assets/resources/pics/' + v.photo + '"></span>' +
                '<span>'+ onlineStatus +' ' + v.firstname + ' ' + v.lastname + '</span></a><br>' +
                '<small class="pull-right">' + type + ' ' + deleteB + '</small>' +
                '<div class="clearfix"></div> </li>'
        });
        strMembers += ' </ul>';
        $('#third-row-data-outlet').html(strMembers);

        var strGroupInfo = '<div class="contact-profile">' +
            '<p style="margin-left: 10px">' + data[0].title + '</p>' +
            '<span style="font-size: 11px; margin-right: 7px;" class="pull-right">' + data.length + ' members&nbsp;&nbsp;&nbsp;<a href="controller/app.php?data_id=' + group_id + '&type=group" title="Download Messages"><i class="fa fa-download"></i></a></span>' +
            '</div>';

        $('#group-info').html(strGroupInfo);

    };

    this.redirectProfile = function (gift) {
        $.redirect("member", {id: $(gift).data("account")}, "post", "_blank");
    };

    this.removeGroupMember = function (gift) {

        var group_id = $(gift).attr('group_id');
        var login_id = $(gift).attr('login_id');

        var data = {
            "function": "removeGroupMember",
            "group_id": group_id,
            'login_id': login_id
        };
        sendRequest.postJSON(data, "controller/app.php", function (response) {
            group.fetchGroupMembers(group_id);
        });
    };

    this.removeGroup = function (gift) {
        var group_id = $(gift).attr('group_id');

        var data = {
            "function": "removeGroup",
            "group_id": group_id,
        };
        sendRequest.postJSON(data, "controller/app.php", function (response) {
            document.location.reload(true);
        });
    };

    this.groupMessagesTemplate = function (group_id, data) {
        // console.log(data);
        var strMessages = '';

        $.each(data, function (k, v) {
            var className = myProfileData.login_id === v.sent_by ? 'sent' : 'replies';

            strMessages += '<li class="' + className + '"><img src="assets/resources/pics/' + v.photo + '">' +
                '<p><small style="font-size: 10px;">' + v.firstname + ' ' + v.lastname + '</small><br>' +
                '' + v.content + '</p></li><div class="clearfix"></div> '
        });
        strMessages += '';

        $('#message-outlet').html(strMessages);
        $(".message-input").removeClass('hidden');
        $("#group_id").val(group_id);
    };

    $('#message_group_form')
        .form({
            onSuccess: function (event, fields) {
                event.preventDefault();
                group.messageGroup();
                $('#message_group_form')[0].reset();
            }
        });


    this.messageGroup = function () {
        var group_id = $("#group_id").val();
        var files = $("#attachedFiles").val();
        files = files ? JSON.parse(files) : '';
        var message = $("#group_message_text").val();
        var data = {
            "function": "sendMessageRevised",
            "message": message,
            "sent_to": group_id,
            "attached_files": files,
            "message_type": "group"
        };
        sendRequest.postJSON(data, "controller/app.php", function (response) {
            $('#group_message_text').removeClass('hidden');
            $("#attachedFiles").val('');
            $("#file_upload_list").html('');
            $('#message_group_form')[0].reset();
            window.fileNamesArray = [];
            group.fetchGroupMessages(group_id);
        });
    };


    this.getUserAccounts = function () {

        var data = {
            "function": "fetchAllAccountsConnected"
        };
        sendRequest.postJSON(data, "controller/app.php", function (response) {
            if (response.status === 'success') {
                var data = response.data;
                var strAllMembers = '';
                // console.log(myProfileData);
                $.each(data, function (k, v) {
                    strAllMembers += '<option value="' + v.login_id + '">' + v.firstname + ' ' + v.lastname + ' (' + v.position + ' at ' + v.company + ')</option>'
                });
                $('#search_member').html(strAllMembers);
            }
        });

    };
}).apply(group);

group.onReady();

// Table search
$(function () {

    $.extend($.expr[':'], {
        'containsi': function (elem, i, match, array) {
            return (elem.textContent || elem.innerText || '').toLowerCase()
                .indexOf((match[3] || "").toLowerCase()) >= 0;
        }
    });

    $("#groupTableSearch").keyup(function () {
        var query = $(this).val();
        $('#group_table_list .rw:not(:containsi(' + query + '))').hide();
        $('#group_table_list .rw:containsi(' + query + ')').show();
    });
});
