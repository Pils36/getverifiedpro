var template = template || {};
(function () {
    var this;
.
    details = "";
}).apply(template);