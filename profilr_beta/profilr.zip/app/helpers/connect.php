<?php
/**
 * Created by PhpStorm.
 * User: Funsho Olaniyi
 * Date: 03/04/2018
 * Time: 05:59 PM
 */

function fetchConnections()
{
	$c = new Connection();
	$myResponse = new Response();
	$type = $_POST['type'];
	$member = $_SESSION['login_id'];
	
	try {
		if ($type == "connected") {
			$result = $c->getMyConnections($member);
		} else {
			$result = $c->getConnectionSuggestions($member);
		}
		//echo $query.$limitStr;
		$myResponse->status = "success";
		$myResponse->message = "Records fetched successfully";
		$myResponse->data = $result;
		return json_encode($myResponse);
		
	} catch (Exception $ex) {
		$myResponse->status = "failed";
		$myResponse->message = $ex->getMessage();
		return json_encode($myResponse);
	}
}

function newConnection(){
	$c = new Connection();
	$myResponse = new Response();
	try {
		$result = $c->createConnection($_SESSION['login_id'],$_POST['member']);
		//echo $query.$limitStr;
		$myResponse->status = "success";
		$myResponse->message = "Connection created successfully";
		$myResponse->data = $result;
		return json_encode($myResponse);
		
	} catch (Exception $ex) {
		$myResponse->status = "failed";
		$myResponse->message = $ex->getMessage();
		return json_encode($myResponse);
	}
}