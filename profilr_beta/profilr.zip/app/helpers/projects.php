<?php
/**
 * Created by PhpStorm.
 * User: Funsho Olaniyi
 * Date: 27/03/2018
 * Time: 01:08 PM
 */

function createProject()
{
	$p = new Project();
	$myResponse = new Response();
	$member = $_SESSION['login_id'];
	
	if (empty($_POST['title'])) {
		$myResponse->status = "failed";
		$myResponse->message = "Please enter a valid title";
		return json_encode($myResponse);
	}
	try {
		$insertId = $p->create($member, $_POST['title']);
//		$p->createProjectTask($insertId, $member, 'Create Project ' . $_POST['title'], 1);
		$myResponse->status = "success";
		$myResponse->message = "Project Created Successfully";
		$myResponse->data = ['project_id' => $insertId];
		return json_encode($myResponse);
	} catch (PDOException $ex) {
		$myResponse = new Response("error", array(), $ex->getMessage());
		return json_encode($myResponse);
	}
}

function createProjectTask()
{
	$p = new Project();
	$myResponse = new Response();
	
	if (empty($_POST['title'])) {
		$myResponse->status = "failed";
		$myResponse->message = "Please enter a valid title";
		return json_encode($myResponse);
	}
	
	
	if (empty($_POST['owner_login_id'])) {
		$myResponse->status = "failed";
		$myResponse->message = "Please select task owner";
		return json_encode($myResponse);
	}
	
	try {
		$p->createProjectTask($_POST['project_id'], $_POST['owner_login_id'], $_POST['title'], 1);
		$myResponse->status = "success";
		$myResponse->message = "Project Task Created Successfully";
		return json_encode($myResponse);
	} catch (PDOException $ex) {
		$myResponse = new Response("error", array(), $ex->getMessage());
		return json_encode($myResponse);
	}
}

function fetchProjects()
{
	$g = new Project();
	$myResponse = new Response();
	$member = $_SESSION['login_id'];
	
	try {
		$projects = $g->getUserProjects($member);
		
		$myResponse->status = "success";
		$myResponse->message = "Operation Successful";
		$myResponse->data = $projects;
		return json_encode($myResponse);
	} catch (Exception $ex) {
		$myResponse->status = "failed";
		$myResponse->message = $ex->getMessage();
		return json_encode($myResponse);
	}
}

function getProjectTasks()
{
	$g = new Project();
	$myResponse = new Response();
	
	if (empty($_POST['project_id'])) {
		$myResponse->status = "failed";
		$myResponse->message = "Please select a project";
		return json_encode($myResponse);
	}
	
	$myResponse = new Response();
	try {
		$projectMessages = $g->getProjectTasks($_POST['project_id']);
		
		$myResponse->status = "success";
		$myResponse->message = "Operation Successful";
		$myResponse->data = $projectMessages;
		return json_encode($myResponse);
	} catch (Exception $ex) {
		$myResponse->status = "failed";
		$myResponse->message = $ex->getMessage();
		return json_encode($myResponse);
	}
}

function getProjectMembers()
{
	$g = new Project();
	$myResponse = new Response();
	
	if (empty($_POST['project_id'])) {
		$myResponse->status = "failed";
		$myResponse->message = "Please select a project";
		return json_encode($myResponse);
	}
	
	$myResponse = new Response();
	try {
		$projectMembers = $g->getProjectMembers($_POST['project_id']);
		
		$myResponse->status = "success";
		$myResponse->message = "Operation Successful";
		$myResponse->data = $projectMembers;
		return json_encode($myResponse);
	} catch (Exception $ex) {
		$myResponse->status = "failed";
		$myResponse->message = $ex->getMessage();
		return json_encode($myResponse);
	}
}


function removeProject()
{
	$g = new Project();
	$member = $_SESSION['login_id'];
	$myResponse = new Response();
	try {
		$projects = $g->deleteProject($_POST['project_id'], $member);
		$g->deleteAllProjectTasks($_POST['project_id']);
		$g->deleteAllProjectComments($_POST['project_id']);
		$myResponse->status = "success";
		$myResponse->message = "Operation Successful";
		$myResponse->data = $projects;
		return json_encode($myResponse);
	} catch (Exception $ex) {
		$myResponse->status = "failed";
		$myResponse->message = $ex->getMessage();
		return json_encode($myResponse);
	}
}

function removeProjectTask()
{
	$g = new Project();
	$myResponse = new Response();
	try {
		$projects = $g->deleteProjectTask($_POST['project_id'], $_POST['task_id']);
		$myResponse->status = "success";
		$myResponse->message = "Operation Successful";
		$myResponse->data = $projects;
		return json_encode($myResponse);
	} catch (Exception $ex) {
		$myResponse->status = "failed";
		$myResponse->message = $ex->getMessage();
		return json_encode($myResponse);
	}
}
