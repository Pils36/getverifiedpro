<?php
/**
 * Created by PhpStorm.
 * User: Funsho Olaniyi
 * Date: 12/04/2018
 * Time: 05:17 PM
 */

// can be where all emails are sent

function sendAdminEmails()
{
	$a = new AccountIndividual();
	$e = new EmailTemplate();
	$myResponse = new Response();
	
	try {
		$subject = $_POST['subject'];
		$messsage = $_POST['message'];
		
		$e->create($subject, $messsage);
		
		$user_group = $_POST['user_group'];
		$email_verify = $_POST['email_verify'];
		$country = $_POST['country'];
		$min_profile_views = $_POST['min_profile_views'];
		$max_profile_views = $_POST['max_profile_views'];
		
		$filter_by = [
			'user_group' => $user_group,
			'email_verify' => $email_verify,
			'country' => $country,
			'min_profile_views' => $min_profile_views,
			'max_profile_views' => $max_profile_views,
		];
		
		$emails = $a->getFilteredUserEmails($filter_by);
		
		$mail = new PHPMailer;
		$mail->isSMTP();
		$mail->Host = 'pro-filr.com';
		$mail->SMTPAuth = true;
		$mail->SMTPSecure = 'ssl';
		$mail->SMTPKeepAlive = true; // SMTP connection will not close after each email sent, reduces SMTP overhead
		$mail->Port = 465;
		$mail->Username = 'subscription@pro-filr.com';
		$mail->Password = 'portFOLIO_2015';
		$mail->setFrom('subscription@pro-filr.com', 'Pro-Filr Inc.');
		$mail->msgHTML($messsage);
		$mail->AltBody = 'To view the message, please use an HTML compatible email viewer!';
		$mail->Subject = $subject;
		
		if(!empty($emails)){
			$mail->AddAddress('segun@johnsmithconsultingltd.com'); // send the mail to yourself
			foreach ($emails as $email){
				$mail->AddBCC($email);
			}
		}
		$mail->send();
		$mail->ClearAllRecipients();
		
		$myResponse->status = "success";
		$myResponse->message = "Sent successfully";
//		$myResponse->data = $emails;
		return json_encode($myResponse);
		
	} catch (Exception $ex) {
		$myResponse->status = "failed";
		$myResponse->message = $ex->getMessage();
		return json_encode($myResponse);
	}
}

function getEmailTemplates()
{
	$e = new EmailTemplate();
	$myResponse = new Response();
	try {
		$result = $e->getEmailTemplates();
		$myResponse->status = "success";
		$myResponse->message = "Records fetched successfully";
		$myResponse->data = $result;
		return json_encode($myResponse);
	}catch (Exception $ex) {
		$myResponse->status = "failed";
		$myResponse->message = $ex->getMessage();
		return json_encode($myResponse);
	}
}

function fetchEmailTemplate()
{
	$e = new EmailTemplate();
	$myResponse = new Response();
	try {
		$result = $e->getAnEmailTemplate($_POST['template_id']);
		$myResponse->status = "success";
		$myResponse->message = "Records fetched successfully";
		$myResponse->data = $result;
		return json_encode($myResponse);
	}catch (Exception $ex) {
		$myResponse->status = "failed";
		$myResponse->message = $ex->getMessage();
		return json_encode($myResponse);
	}
}