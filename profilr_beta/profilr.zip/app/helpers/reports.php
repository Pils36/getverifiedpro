<?php

function getReports()
{
	$myResponse = new Response();
	$r = new Reports();
	try {
		$new_signup = $r->getNumOfNewSignUps();
		$completed_profiles = $r->getNumOfCompletedProfiles();
		$total_users = $r->getTotalNumOfUsers();
		$classic_users = $r->getNumOfClassicUsers();
		$validations = $r->getNumOfValidations();
		$profile_viewed = $r->getNumOfProfileViewed();
		$posted_opportunities = $r->getNumOfPostedOpportunities();
		$active_opportunities = $r->getNumOfActiveOpportunities();
		$expired_opportunities = $r->getNumOfExpiredOpportunities();
		
		$d_total_users = $total_users ? $total_users : 1;
		$d_expired_opp = $expired_opportunities ? $expired_opportunities : 1;
		$data = [
			['name' => 'Number of New SignUps', 'value' => $new_signup],
			['name' => 'Number of Completed Profiles', 'value' => $completed_profiles],
			['name' => 'Total Number of Users', 'value' => $total_users],
			['name' => 'Number of Classic Users', 'value' => $classic_users],
			['name' => 'Percentage of Profile Completion / Total Users', 'value' => ($completed_profiles/$d_total_users)*100],
			['name' => 'Percentage Classic Users / Total Users', 'value' => ($classic_users/$d_total_users)*100],
			
			['name' => 'Number of Validations done', 'value' => $validations],
			['name' => 'Percentage of validations / Total Users', 'value' => ($validations/$d_total_users)*100],
			['name' => 'Number of profile viewed', 'value' => $profile_viewed],
			['name' => 'Number of posted Opportunities', 'value' => $posted_opportunities],
			['name' => 'Number of active opportunities', 'value' => $active_opportunities],
			['name' => 'Number of expired opportunities', 'value' => $expired_opportunities],
			['name' => 'Percentage of Active / Expired Opportunities', 'value' => ($active_opportunities/$d_expired_opp)*100],
		];
		
		$myResponse->status = "success";
		$myResponse->message = "Records fetched successfully";
		$myResponse->data = $data;
	} catch (Exception $ex) {
		$myResponse->status = "failed";
		$myResponse->message = "Cannot get Reports";
	}
	return json_encode($myResponse);
}
