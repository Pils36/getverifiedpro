var emails = emails || {};

emails.ready = function () {
    $(".upgrade").hide();
    $("select").dropdown();
    $(".admin_segment").show();

    $("#email_form").submit(function (event) {
        emails.sendEmails();
        event.preventDefault();
    });

    $("#template_content").change(function () {
        // console.log('template_content');
        var data = {
            "function": "fetchEmailTemplate",
            "template_id": $("#template_content").val()
        };
        sendRequest.postJSON(data, "controller/app.php", function (response) {
            if (response.status === "failed") {
                alert(response.message);
            } else {
                // console.log(response);
                // $.redirect("dashboard");
                $("#subject").val(response.data[0].subject);
                // $("#message").val(response.data[0].body_text);
                // tinyMCE.activeEditor.setContent(response.data[0].body_text);

                // tinyMCE.get('message').setContent(response.data[0].body_text);
                // $.get(response.data[0].body_text, tinyMCE.activeEditor.setContent);
                var html = response.data[0].body_text;
                tinymce.activeEditor.setContent(html, {format: 'raw'});
            }
        });
    });


        $(".admin_link").on("click", function () {
        $(".admin_link").removeClass('active');
        $(this).addClass("active");
        var type = $(this).data("type");
        $(".admin_segment").hide();
        $("#" + type + "_segment").show();
        switch (type) {
           case "emails":
                emails.fetchEmailTemplate();
                break;
            default:
                break;
        }

    });

    emails.fetchBlogs();
};

emails.sendEmails = function () {
    // alert("login");
    // return;
    var data = {
        "function": "sendAdminEmails",
        "subject": $("#subject").val(),
        "message": $("#message").val(),
        "user_group": $("#user_group").val(),
        "email_verify": $("#email_verify").val(),
        "country": $("#country").val(),
        "min_profile_views": $("#min_profile_views").val(),
        "max_profile_views": $("#max_profile_views").val()
    };
    sendRequest.postJSON(data, "controller/app.php", function (response) {
        if (response.status === "failed") {
            alert(response.message);
        } else {
            console.log(response);
            // $.redirect("dashboard");
        }
    });
};

emails.fetchEmailTemplate = function () {
    var data = {
        "function": "getEmailTemplates"
    };
    sendRequest.postJSON(data, "controller/app.php", function (response) {
        var strMsg = "<option value=''>None</option>";
        if (response.status === "success") {
            if (response.data.length) {
                $.each(response.data, function (v, k) {
                    strMsg += "<option value='"+k.id+"'>"+k.subject+"</option>";
                });
            } else {
                strMsg = "<option></option>";
            }

        } else {
            strMsg = "<p>" + response.message + "</p>";
        }
        $("#template_content").html(strMsg);
        // bind view
        $(".blog_link").on("click", function () {
            emails.viewBlog(this);
        });

    });
};

emails.ready();