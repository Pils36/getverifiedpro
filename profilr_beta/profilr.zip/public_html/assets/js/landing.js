var landing = landing || {};
(function () {
    this.ready = function () {
        //fetch page contents
        NProgress.start();
        var data = {
            "function": "fetchLanding"
        };
        sendRequest.postJSON(data, "controller/app.php", function (response) {
            if (response.status === "success") {
                landing.blogTemplate(response.data.blogposts);
                landing.opportunityTemplate(response.data.opportunities);
                landing.suggestionTemplate(response.data.suggestions);
            }


        });
        NProgress.done();

    },

        this.suggestionTemplate = function (data) {
            if (!data.length) {
                $("#suggestion_list").html(landing.emptyResponse);
                return;
            }
            var strPosts = "";
            $.each(data, function (v, k) {

                strPosts += '<li><a onclick="landing.redirectProfile(this)"  data-account="' + k.login_id + '"><span><img src="assets/resources/pics/' + k.photo + '"></span>' + k.firstname + ' ' + k.lastname + '<span><br>' + k.in_common + '</span></a></li>';
            });
            strPosts += "";
            $("#suggestion_list").html(strPosts);

        },

        this.redirectProfile = function (gift) {
            $.redirect("member", {id: $(gift).data("account")}, "post");
        };

    this.opportunityTemplate = function (data) {
        if (!data.length) {
            $("#opportunity_list").html(landing.emptyResponse);
            return;
        }
        var strPosts = "";
        $.each(data, function (v, k) {

            strPosts += "<section class='projects section'><div class='section-inner'>" +
                "<h2 class='heading sr-only'>" + k.subject + "</h2>" +
                "<div class='content'><div class='item'>" +
                "<h3 class='title'><a href='#'>" + k.subject + "</a><br><span class='date'>Deadline: " + k.deadline + ", Location: " + k.location + "</span></h3>" +
                "<div class='clearfix'></div> <p class='summary'>" + k.description + "</p>" +
                "<p><a class='more-link' href='posts'><i class='fa fa-external-link'></i> View</a></p>" +
                "</div></div></div></section><!--//section-->";
        });
        strPosts += "";
        $("#opportunity_list").html(strPosts);

    },

        this.blogTemplate = function (data) {
            if (!data.length) {
                $("#blog_list").html(landing.emptyResponse);
                return;
            }
            var strPosts = "<div class='ui comments'>";
            $.each(data, function (v, k) {
                // strPosts += "<div class='comment'> <div class='content'> <a class='subject'>" + k.title + "</a> <div class='metadata'> <div class='date'>" + k.date_posted + "</div> <span class='reply green text'>" + k.comments + " Comments</span> </div> <div class='text'>" + k.summary + "</div> <div class='actions'> <a class='read'>Read</a> </div> </div> </div> <div class='ui divider'></div>";

                strPosts += "<div class='section-inner'>" +
                    "<h2 class='heading'>" + k.title + "</h2>" +
                    "<p><a class='more-link' href='blog'><i class='fa fa-external-link'></i> Read More</a></p></div>"
            });
            strPosts += "</div>";
            $("#blog_list").html(strPosts);


        },

        this.emptyResponse = "<div class='ui comments'><div class='comment'><div class='text'>No record found</div> </div></div>";


}).apply(landing);

landing.ready();