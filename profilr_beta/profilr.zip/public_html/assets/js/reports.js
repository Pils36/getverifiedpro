var reports = reports || {};

reports.ready = function () {
    $(".upgrade").hide();
    $("select").dropdown();

    $(".admin_link").on("click", function () {
        $(".admin_link").removeClass('active');
        $(this).addClass("active");
        var type = $(this).data("type");
        $(".admin_segment").hide();
        $("#" + type + "_segment").show();
        switch (type) {
            case "reports":
                reports.fetchReports();
                break;
            default:
                break;
        }
    });
};

reports.fetchReports = function () {
    var data = {
        "function": "getReports"
    };
    sendRequest.postJSON(data, "controller/app.php", function (response){
        var strMsg = '';
        if (response.status === "success") {

            if (response.data.length) {
                strMsg += "<table class='ui  striped table'> <thead> <tr> <th>#</th><th>METRIC NAME</th> <th>VALUE</th></tr> </thead> <tbody>";
                $.each(response.data, function (v, k) {
                    strMsg += "<tr><td>" + (v + 1) + "</td><td>" + k.name + "</td><td>" + k.value + "</td></tr>";
                });
                strMsg += "</tbody></table>";
            } else {
                strMsg = "<p>No Report</p>";
            }

        } else {
            strMsg = "<p>" + response.message + "</p>";
        }
        $("#reports_content").html(strMsg);
    });
};
reports.ready();