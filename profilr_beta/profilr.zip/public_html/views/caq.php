<?php include("partials/s_head.html"); ?>
<body class="Site">
<div class="ui grid container Site-content" style="padding-top: 50px;width: 90% !important;">
	<?php include("partials/s_general_nav.html"); ?>

    <div class="row" id="content_row">
        <div class="twelve wide column">
            <div class="ui  vertical segment">
				<?php include("partials/s_right_rail.html"); ?>
                <spcontent>
                    <h3 class="ui header">Commonly Asked Questions</h3>
                    <div class="ui vertical segment" style="height: 65vh;overflow-y: auto">

                    </div>

                </spcontent>

            </div>
        </div>
    </div>
    <!-- content row ends-->

</div>
<footer>
	<?php include("partials/s_footer.html"); ?>
</footer>
<?php include("partials/scripts.html"); ?>
</body>
