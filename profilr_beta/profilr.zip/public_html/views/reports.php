<?php
header('Expires: Sun, 01 Jan 2014 00:00:00 GMT');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Cache-Control: post-check=0, pre-check=0', FALSE);
header('Pragma: no-cache');

if (empty($_SESSION['admin_login'])) {
	$_SESSION['oauth_error'] = 'Please Login';
	header('Location: account');
	exit;
}
?>


<!DOCTYPE html>
<html>
<?php include("partials/s_head.html"); ?>

<!--<link rel="stylesheet" href="assets/lib/bootstrap-select/css/bootstrap-select.min.css">-->
<body class="Site">

<div class="ui grid container Site-content" style="padding-top: 50px;width: 90% !important;">
    <div id="nav_row" class="ui fixed secondary large menu header" style="border-bottom: 2px solid #79af76; background-color: white">
        <div class="ui container">
            <a href="home" class="header item">
                <img class="logo" style="width: 100%" src="assets/images/prologo.png">
            </a>
            

            <div class="right menu profile_menu">
<!--                <span class="item"> <a href="upgrade" class="ui positive button">Upgrade</a></span>-->
                <a href="dashboard" class="item">Home</a>
                <a href="reports" class="active item">Reports</a>
                <a href="email" class="item">Email Templates</a>
                <a class="item profile_link" data-view="landing"><i class="sign out icon"></i>Logout</a>

            </div>
        </div>
    </div>
    <div class="row" style="margin-top: 30px;"></div>


    <!-- content row -->

    <div class="row">


        <div class="ui sixteen wide column" id="middle-column">


            <div class="ui grid">
                <div class="four wide column">
                    <div class="ui vertical fluid tabular menu">
                        <a class="item admin_link" href="">Reports</a>
                    </div>
                </div>
                <div class="twelve wide stretched column">
                    <div class="ui segment admin_segment" style="margin-top: 0px; display: none;"
                         id="reports_segment">
                        <h3 class="ui top attached red header">Report</h3>
                        <div class="ui bottom attached segment" style="height: 75vh; overflow-y: auto;"
                             id="reports_content">
                            
                        </div>
                    </div>
                </div>
            </div>


        </div>

    </div>


    <!-- content row -->

</div>

<!-- <footer></footer> -->


<footer>
    <!--	--><?php //include("partials/s_footer.html"); ?>
</footer>
<?php include("partials/scripts.html"); ?>
<script type="text/javascript" src="assets/js/reports.js"></script>

</body>