<?php
header('Expires: Sun, 01 Jan 2014 00:00:00 GMT');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Cache-Control: post-check=0, pre-check=0', FALSE);
header('Pragma: no-cache');

?>
<!DOCTYPE html>
<html>
<?php include("partials/b_head.html"); ?>
<?php //echo "token:".$_SESSION['token']; ?>
<body>
<?php
if (!isset($_SESSION['token'])) {
	include("partials/b_general_nav.html");
} else {
	include("partials/b_profile_nav.html");
}
?>
<div class="container sections-wrapper">
    <div class="row">
        <div style="margin-left: 15%;" class="primary col-md-10 col-sm-12 col-xs-12">
            <div class="col-sm-5">
                <div class="upbox">
                    <h3 class="title">Free Solution</h3>
                </div>
                <div class="upbox-content">
                    <p>Connect</p>

                    <div class="upbox-submit">
                        <p>Select Plan</p>

                    </div>
                </div>

            </div>
            <div class="col-sm-5">
                <div class="upbox1">
                    <h3 class="title">Paid Solution</h3>
                </div>

                <div class="upbox1-content">
                    <p>Connect</p>
                    <p>Engage</p>
                    <p>Project</p>

                    <div class="upbox1-submit">
                        <a data-toggle="modal" data-target="#myClassic">Select Plan</a>
                    </div>
                </div>

            </div>

        </div><!--//primary-->

    </div><!--//row-->
</div><!--//masonry-->
<div class="modal fade" id="myClassic" tabindex="-1" role="dialog" aria-labelledby="createGroupLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title" id="createGroupLabel">Upgrade to Classic, Get Profiled</h4>
            </div>
            <div class="modal-body">

                <p>
                    Classic Plan offers awesome opportunities not available to free users. Classic Plan means:
                <ul>
                    <li>More business opportunities as you rank higher during the search for your
                        specialisations
                    </li>
                    <li>More profile views, recommendations and engagements</li>
                    <li>More visibility through targeted advertisement</li>
                </ul>
                </p>
                <div class="ui divider"></div>
                <p>
                <form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_blank">
                    <input type="hidden" name="cmd" value="_s-xclick">
                    <input type="hidden" name="hosted_button_id" value="KH2G3CLSE3H8N">
                    <table>
                        <tr>
                            <td><input type="hidden" name="on0" value="Subscription Options">Subscription
                                Options
                            </td>
                        </tr>
                        <tr>
                            <td><select name="os0">
                                    <option value="Monthly Plan">Monthly Plan : $10.00 CAD - monthly</option>
                                    <option value="Annual Plan">Annual Plan : $100.00 CAD - yearly</option>
                                </select></td>
                        </tr>
                    </table>
                    <input type="hidden" name="currency_code" value="CAD">
                    <input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_subscribeCC_LG.gif"
                           border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
                    <img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1"
                         height="1">
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<?php include("partials/scripts.html"); ?>

<footer>
	<?php include("partials/s_footer.html"); ?>
</footer>
<script type="text/javascript" src="assets/js/search.js"></script>
</body>
</html>