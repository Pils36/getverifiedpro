<?php
header('Expires: Sun, 01 Jan 2014 00:00:00 GMT');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Cache-Control: post-check=0, pre-check=0', FALSE);
header('Pragma: no-cache');

if (empty($_SESSION['admin_login'])) {
	$_SESSION['oauth_error'] = 'Please Login';
	header('Location: account');
	exit;
}
?>


<!DOCTYPE html>
<html>
<?php include("partials/s_head.html"); ?>

<!--<link rel="stylesheet" href="assets/lib/bootstrap-select/css/bootstrap-select.min.css">-->
<body class="Site">

<div class="ui grid container Site-content" style="padding-top: 50px;width: 90% !important;">
    <div id="nav_row" class="ui fixed secondary large menu header" style="border-bottom: 2px solid #79af76; background-color: white">
        <div class="ui container">
            <a href="home" class="header item">
                <img class="logo" style="width: 100%" src="assets/images/prologo.png">
            </a>
            

            <div class="right menu profile_menu">
<!--                <span class="item"> <a href="upgrade" class="ui positive button">Upgrade</a></span>-->
                <a href="dashboard" class="item">Home</a>
                <a href="reports" class="item">Reports</a>
                <a href="email" class="active item">Email Templates</a>
                <a class="item profile_link" data-view="landing"><i class="sign out icon"></i>Logout</a>

            </div>
        </div>
    </div>
    <div class="row" style="margin-top: 30px;"></div>


    <!-- content row -->

    <div class="row">


        <div class="ui sixteen wide column" id="middle-column">


            <div class="ui grid">
                <div class="four wide column">
                    <div class="ui vertical fluid tabular menu">
                        <a class="active item admin_link" data-type="emails">Create Email Template</a>
                        <a class="item admin_link" data-type="templates">Email Templates</a>
                    </div>
                </div>
                    <div class="ui segment admin_segment" style="margin-top: 0px; display: none;"
                         id="emails_segment">
                        <h3 class="ui top attached red header">Emails</h3>
                        <div class="ui bottom attached segment" style="height: 75vh; overflow-y: auto;"
                             id="emails_content">
<!--                            <h2>Filter Tags</h2>-->
                            <form class="ui form error" id="email_form">
                                <div class="field">
                                    <label for="template_content">Select Template to Edit</label>
                                    <select id="template_content">
                                        <option>No Template</option>
                                    </select>
                                </div>
                                <div class="field">
                                    <label for="subject">Subject</label>
                                    <input type="text" placeholder="Enter Subject" id="subject">
                                </div>
                                <div class="field">
                                    <label for="message">Compose Message</label>
                                    <textarea id="message" placeholder="Enter Message" name="message">
                                    
                                    </textarea>
                                </div>
                                <span>
                                    <input type="submit" value="Save Email Template" class="ui positive button right">
                            </span>
                            </form>

                        </div>
                    </div>
                </div>
            </div>


        </div>

    </div>


    <!-- content row -->

</div>

<!-- <footer></footer> -->

<footer>
    <!--	--><?php //include("partials/s_footer.html"); ?>
</footer>
<?php include("partials/scripts.html"); ?>

<!--<script type="text/javascript">-->
<!--    $(document).ready(function () {-->
<!--        $('.selectpicker').selectpicker();-->
<!--    });-->
<!--</script>-->
<script type="text/javascript" src="assets/lib/tinymce/jquery.tinymce.min.js"></script>
<script type="text/javascript" src="assets/lib/tinymce/tinymce.min.js"></script>
<script>
    tinymce.init({
        selector: 'textarea',
        height: 100700,
        menubar: true,
        theme: 'modern',
        plugins: [
            'advlist anchor autolink autoresize autosave save code colorpicker contextmenu emoticons fullpage hr image imagetools importcss insertdatetime link lists media paste preview searchreplace tabfocus table textcolor textpattern toc wordcount'
        ],
        toolbar: 'insert | undo redo |  formatselect | bold italic backcolor  | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat |',
        content_css: [
            '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',]
    });
</script>
<script type="text/javascript" src="assets/js/emails.js"></script>

</body>