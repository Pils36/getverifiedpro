<?php

header('Expires: Sun, 01 Jan 2014 00:00:00 GMT');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Cache-Control: post-check=0, pre-check=0', FALSE);
header('Pragma: no-cache');


if (!validateLogin()) {
	$_SESSION['oauth_error'] = 'Please Login';
	header('Location: account');
	exit;
}
?>
<!DOCTYPE html>
<html>
<?php include("partials/b_head.html"); ?>
<link rel="stylesheet" href="assets/lib/bootstrap-select/css/bootstrap-select.min.css">

<?php //echo "token:".$_SESSION['token']; ?>
<body>
<?php include("partials/b_profile_nav.html"); ?>

<div class="container sections-wrapper">
    <div class="row">
        <div class="secondary col-md-3 col-sm-12 col-xs-12">
            <aside class="info aside section">
                <div class="section-inner">
                    <div class="content quote">
                        <div id="contacts">
                            <div class='wrap'>Projects

                                <a href="#" style="padding: 0 10px;" data-toggle="modal" class="pull-right"
                                   data-target="#createProject"><i class="fa fa-plus"></i> Create Project</a>

                            </div>
                            <br>
                            <div id='search'><input
                                        type='search' class="form-control" id='projectTableSearch'
                                        placeholder='Search Projects...'/></div>
                        </div>
                        <br>
                        <div class="clearfix"></div>

                        <ul id="project_table_list" class="list-unstyled">

                        </ul>
                    </div><!--//content-->
                </div><!--//section-inner-->
            </aside><!--//aside-->

        </div><!--//secondary-->

        <div class="primary col-md-6 col-sm-12 col-xs-12">
            <div id="frame">
                <div id="sidepanel">
                    <div id="task_body" class="hidden">
                        <div id='profile'>
                            <div class='wrap'><p>Tasks</p>
                                <a href="#" style="padding: 0 10px;" data-toggle="modal" class="pull-right" id="create_task"
                                   data-target="#createTask"><i class="fa fa-plus"></i> Create Task</a>
                            </div>
                        </div>
                        <div id='search'><label for=''><i class='fa fa-search' aria-hidden='true'></i></label><input
                                    type='text' id='taskTableSearch' placeholder='Search Tasks...'/></div>
                        <div id="contacts">
                            <ul id="task_table_list">

                            </ul>
                        </div>
                    </div>

                </div>

                <div class="content">
                    <div id="project-info">

                    </div>
                    <div class="messages">
                        <ul id="message-outlet">

                        </ul>
                    </div>

                    <div class="message-input">
                        <form class="wrap hidden" id="message_project_form" method="post" action="controller/app.php">
                            <div class="upload">
                                <div class="drop">
                                    <ul id="file_upload_list">

                                    </ul>
                                </div>
                            </div>
                            <input type="text" id="project_message_text" class="form-control"
                                   placeholder="Write your message..."/>
                            <input type="hidden" id="project_id">
                            <input type="hidden" id="attachedFiles">
                            <button class="submit" type="submit"><i class="fa fa-paper-plane" aria-hidden="true"></i>
                            </button>
                            <div class="clearfix"></div>
                            <div id="upload" class="upload">
                                <div id="drop" class="drop">
                                    <a><span>Attach File <i class="fa fa-paperclip attachment"
                                                            aria-hidden="true"></i></span></a>
                                    <input type="file" name="attachment" multiple/>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div><!--//masonry-->
        </div><!--//primary-->
        <div class="secondary col-md-3 col-sm-12 col-xs-12">
            <aside class="info aside section">
                <div class="section-inner" id="third-row-data-outlet">

                </div>
            </aside>
            
            <aside class="info aside section">
                <div class="section-inner" id="files-row-data-outlet">

                </div>
            </aside>
        </div>
    </div>

    <!-- Create Project Modal -->
    <div class="modal fade" id="createProject" tabindex="-1" role="dialog" aria-labelledby="createProjectLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="createProjectLabel">Create Project</h4>
                </div>
                <div class="modal-body">
                    <div id="project_response"></div>
                    <form id="create_project_form" autocomplete="off">
                        <div class="form-project">
                            <label for="title">Project Title</label>
                            <input type="text" class="form-control" id="project_title" placeholder="Project Name">
                        </div>
                        <BR>
                        <button type="submit" class="btn btn-default" style="padding: 10px 15px; width: 20%">Submit</button>
                    </form>
                </div>
                <div class="modal-footer">
<!--                    <button type="submit" class="btn btn-primary">Submit</button>-->
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Create Task Modal -->
    <div class="modal fade" id="createTask" tabindex="-1" role="dialog" aria-labelledby="createTaskLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="createTaskLabel">Create Task</h4>
                </div>
                <div class="modal-body">
                    <div id="task_response"></div>
                    <form id="create_task_form" autocomplete="off">
                        <div class="form-group">
                            <label for="task_title">Task Title</label>
                            <input type="text" class="form-control" id="task_title" placeholder="Task Name">
                        </div>
                        <input type="hidden" name="project_id" id="project_id">
                        <div class="form-group">
                            <label for="task_owners">Assign Members</label>
                            <select id="task_owners" class="form-control selectpicker" data-live-search="true">

                            </select>
                        </div>

                        <button type="submit" class="btn btn-default">Submit</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Send Private Message -->
    <div class="modal fade" id="sendMessage" tabindex="-1" role="dialog" aria-labelledby="sendMessageLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="createTaskLabel">Compose A Message</h4>
                </div>
                <div class="modal-body">
                    <div id="message_response"></div>
                    <form id="message_member_form" autocomplete="off">
                        <div class="form-group">
                            <label for="subject">Subject</label>
                            <input type="text" class="form-control" id="subject" placeholder="Subject">
                        </div>
                        <input type="hidden" name="member_id" id="member_id">
                        <div class="form-group">
                            <label for="message">Message</label>
                            <textarea id="message_text" class="form-control" placeholder="Write Message">

                            </textarea>
                        </div>

                        <button type="submit" class="btn btn-default">Submit</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
	<?php include("partials/scripts.html"); ?>
    <script type="text/javascript" src="assets/lib/bootstrap-select/js/bootstrap-select.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('.selectpicker').selectpicker();
        });
    </script>
    <script type="text/javascript" src="assets/js/project.js"></script>

    <script src="assets/upload/js/jquery.knob.js"></script>
    <script src="assets/upload/js/jquery.ui.widget.js"></script>
    <script src="assets/upload/js/jquery.iframe-transport.js"></script>
    <script src="assets/upload/js/jquery.fileupload.js"></script>
    <script src="assets/upload/js/script.js"></script>
</body>
</html>