<?php include("partials/s_head.html"); ?>
<body class="Site">
<div class="ui grid container Site-content" style="padding-top: 50px;width: 90% !important;">
	<?php include("partials/s_general_nav.html"); ?>

    <div class="ui row grid">
        <div class="row">
            <div class="ui four wide column"></div>


            <div class="ui eight wide column" id="verify_response"></div>


            <div class="ui four wide column"></div>


        </div>
    </div>

</div>

<footer>
	<?php include("partials/s_footer.html"); ?>
</footer>

<?php include("partials/scripts.html"); ?>
<script type="text/javascript" src="assets/js/app.js"></script>
<script type="text/javascript" src="assets/js/verify.js"></script>

</body>
</html>