<?php
header('Expires: Sun, 01 Jan 2014 00:00:00 GMT');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Cache-Control: post-check=0, pre-check=0', FALSE);
header('Pragma: no-cache');

if (!validateLogin()) {
	$_SESSION['oauth_error'] = 'Please Login';
	header('Location: account');
	exit;
}
?>
<!DOCTYPE html>
<html>
<?php include("partials/b_head.html"); ?>
<?php //echo "token:".$_SESSION['token']; ?>
<body>
<?php include("partials/b_profile_nav.html"); ?>
<div class="container sections-wrapper">
    <div class="row">

        <div class="secondary col-md-3 col-sm-12 col-xs-12">
            <aside class="info aside section">
                <div class="section-inner">
                    <img class="profile_picture img-thumbnail" style="width: 100%" src="assets/images/man.png"/>
                </div>
                <div class="section-inner">
                    <h4 class="header" id="profile_name"></h4>
                    <div class="description" id="profile_current_position"></div>
                    <br>
                    <div class="clearfix"></div>
                    <!--                    <hr>-->
                    <div class="content quote">


                        <ul class="list-unstyled">
                            <li>Validations<span class="label label-success pull-right"
                                                 id="profile_validations">0</span></li>
                            <li>Profile Views<span class="label label-danger pull-right"
                                                   id="profile_validations">0</span></li>
                            <li><a href="posts"> Messages</a><span class="label label-warning pull-right" id="profile_validations">0</span>
                            </li>
                            <li><a href="invites"> Connections</a><span class="label label-primary pull-right" id="profile_validations">0</span>
                            </li>
                            <li><a href="groups"> Groups</a><span class="label label-default pull-right" id="profile_validations">0</span>
                            </li>
                        </ul>
                    </div><!--//content-->
                </div><!--//section-inner-->
            </aside><!--//aside-->

        </div><!--//secondary-->
        <div class="primary col-md-6 col-sm-12 col-xs-12">
            <!--            <section class="about section">-->
            <!--                <div class="section-inner">-->
            <!--                    <h2 class="heading">Post Opportunity</h2>-->
            <!--                    <div class="content">-->
            <!--                        <div class="item">-->
            <!--                            <div class="form-group">-->
            <!--                                <textarea></textarea>-->
            <!--                                <button class="btn btn-success pull-right">Post</button>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                    </div><!--//content-->
            <!--                </div><!--//section-inner-->
            <!--            </section><!--//section-->


            <div id="opportunity_list">

            </div>
        </div><!--//primary-->

        <div class="secondary col-md-3 col-sm-12 col-xs-12">
            <aside class="info aside section" id="people_list">
                <div class="section-inner">
                    <h2 class="heading">People You May Know</h2>
                    <div class="content quote">
                        <ul class="list-unstyled" id="suggestion_list">

                        </ul>
                    </div><!--//content-->
                </div><!--//section-inner-->
            </aside><!--//aside-->

            <aside class="blog aside section" id="blog_list">

            </aside><!--//section-->
            <aside class="info aside section">
                <div class="section-inner">
                    <h2 class="heading">Recommendations</h2>
                    <div class="content quote">
                        <ul class="list-unstyled">
                            <!--                                    <li><span class="sr-only">Location:</span>San Francisco, US</li>-->
                        </ul>
                    </div><!--//content-->
                </div><!--//section-inner-->
            </aside><!--//section-->


        </div><!--//secondary-->
    </div><!--//row-->
</div><!--//masonry-->


<!-- form modal -->


<!-- confirm modal -->

<!-- industry experience modal -->

<!-- industry experience modal -->


<!-- industry experience project modal -->

<!-- industry experience modal -->


<?php include("partials/scripts.html"); ?>

<script type="text/javascript" src="assets/js/landing.js"></script>

</body>
</html>