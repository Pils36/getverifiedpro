MATHML PLUGIN
=============
by loclamor

You will need a fonctionnal MahJax installation (with $...$ as inline formulas and $$...$$ as bloc formulas defined in MathJax configuration) in order to use this plugin.
MathJax could be found here : https://www.mathjax.org/

A Trumbowyg-mathml demo can be found there : http://utest.favier.it/mathtest/
